let highScores = { easy: 0, normal: 0, hard: 0, oni: 0 };

document.getElementById("connectBtn").addEventListener("click", async () => {
  try {
    const device = await navigator.bluetooth.requestDevice({
      filters: [{ namePrefix: "BBC micro:bit" }],
      optionalServices: ["6e400001-b5a3-f393-e0a9-e50e24dcca9e"]
    });
    const server = await device.gatt.connect();
    const service = await server.getPrimaryService("6e400001-b5a3-f393-e0a9-e50e24dcca9e");
    const characteristic = await service.getCharacteristic("6e400003-b5a3-f393-e0a9-e50e24dcca9e");

    await characteristic.startNotifications();
    alert("✅ 接続完了！");

    characteristic.addEventListener("characteristicvaluechanged", event => {
      const text = new TextDecoder().decode(event.target.value);
      const match = text.match(/Mode:(\w+), Score:(\d+)/);
      if (match) {
        const mode = match[1];
        const score = parseInt(match[2]);

        document.getElementById("scoreDisplay").textContent = `${score}`;

        if (score > highScores[mode]) {
          highScores[mode] = score;
          document.getElementById(`${mode}High`).textContent = `${mode.charAt(0).toUpperCase() + mode.slice(1)}: ${score}`;
        }

        const now = new Date().toLocaleString();
        const row = document.getElementById("historyTable").insertRow(-1);
        row.insertCell(0).textContent = now;
        row.insertCell(1).textContent = mode;
        row.insertCell(2).textContent = score;
      }
    });
  } catch (err) {
    alert("接続エラー: " + err);
  }
});